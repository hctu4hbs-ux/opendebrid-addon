const config = require('./config');

class SmartAlgorithm {
    /**
     * Filter and rank torrent sources
     * @param {Array} sources - Array of torrent sources
     * @returns {Array} Filtered and ranked sources
     */
    filterAndRank(sources) {
        console.log(`[SmartAlgorithm] Processing ${sources.length} sources`);

        // Step 1: Filter out bad sources
        const filtered = sources.filter(source => this.isValidSource(source));
        console.log(`[SmartAlgorithm] ${filtered.length} sources passed filtering`);

        // Step 2: Calculate score for each source
        const scored = filtered.map(source => ({
            ...source,
            score: this.calculateScore(source),
        }));

        // Step 3: Sort by score (descending)
        const ranked = scored.sort((a, b) => b.score - a.score);

        console.log(`[SmartAlgorithm] Top source: ${ranked[0]?.title} (Score: ${ranked[0]?.score.toFixed(2)})`);

        return ranked;
    }

    /**
     * Check if a source is valid based on filtering criteria
     * @param {Object} source - Torrent source
     * @returns {boolean} True if valid
     */
    isValidSource(source) {
        // Check minimum seeders
        if (source.seeders < config.algorithm.minSeeders) {
            return false;
        }

        // Check if source is completely dead
        if (source.seeders === 0 && source.leechers > 0) {
            return false;
        }

        // Check for unrealistic file sizes (basic check)
        if (this.hasUnrealisticSize(source)) {
            return false;
        }

        // Check if quality is mentioned
        if (!this.hasQualityInfo(source.title)) {
            return false;
        }

        return true;
    }

    /**
     * Check if file size is unrealistic
     * @param {Object} source - Torrent source
     * @returns {boolean} True if size is unrealistic
     */
    hasUnrealisticSize(source) {
        const sizeStr = source.size.toLowerCase();
        
        // Extract size in MB
        let sizeInMB = 0;
        if (sizeStr.includes('gb')) {
            sizeInMB = parseFloat(sizeStr) * 1024;
        } else if (sizeStr.includes('mb')) {
            sizeInMB = parseFloat(sizeStr);
        }

        // Check for 1080p movies that are too small (likely fake)
        if (source.title.toLowerCase().includes('1080p') && sizeInMB < 500) {
            return true;
        }

        // Check for 4K movies that are too small
        if ((source.title.toLowerCase().includes('2160p') || source.title.toLowerCase().includes('4k')) && sizeInMB < 2000) {
            return true;
        }

        return false;
    }

    /**
     * Check if title contains quality information
     * @param {string} title - Torrent title
     * @returns {boolean} True if quality info is present
     */
    hasQualityInfo(title) {
        const qualityKeywords = ['2160p', '4k', '1080p', '720p', '480p', 'web', 'bluray', 'brrip'];
        const lowerTitle = title.toLowerCase();
        return qualityKeywords.some(keyword => lowerTitle.includes(keyword));
    }

    /**
     * Calculate score for a source
     * @param {Object} source - Torrent source
     * @returns {number} Score
     */
    calculateScore(source) {
        const seedersScore = this.calculateSeedersScore(source.seeders);
        const ratioScore = this.calculateRatioScore(source.seeders, source.leechers);
        const qualityScore = this.calculateQualityScore(source.title);

        const weights = config.algorithm.weights;
        const totalScore = 
            (weights.seeders * seedersScore) +
            (weights.ratio * ratioScore) +
            (weights.quality * qualityScore);

        return totalScore;
    }

    /**
     * Calculate seeders score (0-1)
     * @param {number} seeders - Number of seeders
     * @returns {number} Score between 0 and 1
     */
    calculateSeedersScore(seeders) {
        // Logarithmic scale: more seeders = better, but with diminishing returns
        return 1 - (1 / (seeders + 1));
    }

    /**
     * Calculate ratio score (0-1)
     * @param {number} seeders - Number of seeders
     * @param {number} leechers - Number of leechers
     * @returns {number} Score between 0 and 1
     */
    calculateRatioScore(seeders, leechers) {
        if (leechers === 0) {
            return 1; // Perfect ratio
        }
        const ratio = seeders / leechers;
        return 1 - (1 / (ratio + 1));
    }

    /**
     * Calculate quality score based on keywords in title
     * @param {string} title - Torrent title
     * @returns {number} Quality score
     */
    calculateQualityScore(title) {
        const lowerTitle = title.toLowerCase();
        let score = 0;

        // Check each quality keyword
        for (const [keyword, points] of Object.entries(config.quality)) {
            if (lowerTitle.includes(keyword.toLowerCase())) {
                score += points;
            }
        }

        // Normalize to 0-1 range (assuming max possible score is around 1.5)
        return Math.max(0, Math.min(1, score / 1.5));
    }

    /**
     * Format source for Stremio display
     * @param {Object} source - Torrent source with score
     * @returns {Object} Formatted stream object for Stremio
     */
    formatForStremio(source) {
        const quality = this.extractQuality(source.title);
        const title = `[OD] ${quality} | ${source.size} | 🌱 ${source.seeders}`;

        return {
            name: 'OpenDebrid',
            title: title,
            infoHash: this.extractInfoHash(source.magnet),
            sources: [source.magnet],
        };
    }

    /**
     * Extract quality from title
     * @param {string} title - Torrent title
     * @returns {string} Quality string
     */
    extractQuality(title) {
        const qualities = ['2160p', '4K', '1080p', '720p', '480p'];
        for (const quality of qualities) {
            if (title.toLowerCase().includes(quality.toLowerCase())) {
                return quality;
            }
        }
        return 'Unknown';
    }

    /**
     * Extract info hash from magnet link
     * @param {string} magnet - Magnet link
     * @returns {string} Info hash
     */
    extractInfoHash(magnet) {
        if (!magnet) return null;
        const match = magnet.match(/btih:([a-zA-Z0-9]+)/);
        return match ? match[1].toLowerCase() : null;
    }
}

module.exports = SmartAlgorithm;

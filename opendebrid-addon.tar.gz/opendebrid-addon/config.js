// Configuration for OpenDebrid Addon

module.exports = {
    // Addon information
    addon: {
        id: 'com.opendebrid.addon',
        version: '1.0.0',
        name: 'OpenDebrid',
        description: 'OpenDebrid - Smart free torrent source selector - Get the best streaming experience without paid services',
        logo: 'https://i.imgur.com/example.png', // TODO: Replace with actual logo
        background: 'https://i.imgur.com/example-bg.png', // TODO: Replace with actual background
    },

    // Torrent sources configuration
    sources: {
        enabled: ['YTS', '1337x', 'Eztv'],
        timeout: 10000, // 10 seconds timeout for each source
    },

    // Smart algorithm weights
    algorithm: {
        weights: {
            seeders: 0.5,
            ratio: 0.3,
            quality: 0.2,
        },
        minSeeders: 5,
        minRatio: 0.1,
    },

    // Quality scoring
    quality: {
        '2160p': 1.0,
        '4K': 1.0,
        '1080p': 0.8,
        '720p': 0.6,
        '480p': 0.4,
        'WEB-DL': 0.1,
        'WEBRip': 0.1,
        'BluRay': 0.2,
        'BRRip': 0.15,
        'CAM': -0.5,
        'HDCAM': -0.5,
        'TS': -0.3,
    },

    // Cache settings
    cache: {
        enabled: true,
        ttl: 3600, // 1 hour in seconds
        checkperiod: 600, // Check for expired keys every 10 minutes
    },

    // Display settings
    display: {
        maxResults: 1, // Show only the best result by default
        showSeeders: true,
        showSize: true,
        showQuality: true,
    },
};

const { addonBuilder } = require('stremio-addon-sdk');
const NodeCache = require('node-cache');
const config = require('./config');
const SourceAggregator = require('./sourceAggregator');
const SmartAlgorithm = require('./smartAlgorithm');

// Initialize components
const cache = new NodeCache({
    stdTTL: config.cache.ttl,
    checkperiod: config.cache.checkperiod,
    useClones: false,
});

const aggregator = new SourceAggregator();
const algorithm = new SmartAlgorithm();

// Define manifest
const manifest = {
    id: config.addon.id,
    version: config.addon.version,
    name: config.addon.name,
    description: config.addon.description,
    logo: config.addon.logo,
    background: config.addon.background,
    
    resources: ['stream'],
    types: ['movie', 'series'],
    
    catalogs: [],
    
    idPrefixes: ['tt'], // Support IMDB IDs
};

// Create addon builder
const builder = new addonBuilder(manifest);

// Define stream handler
builder.defineStreamHandler(async ({ type, id }) => {
    try {
        console.log(`\n[Addon] Stream request: type=${type}, id=${id}`);

        // Check cache first
        const cacheKey = `${type}:${id}`;
        if (config.cache.enabled) {
            const cached = cache.get(cacheKey);
            if (cached) {
                console.log('[Addon] Returning cached result');
                return { streams: cached };
            }
        }

        // Parse ID (format: tt1234567 or tt1234567:1:1 for series)
        const [imdbId, season, episode] = id.split(':');
        
        // Build search query
        const query = await buildSearchQuery(imdbId, type, season, episode);
        
        if (!query) {
            console.log('[Addon] Could not build search query');
            return { streams: [] };
        }

        console.log(`[Addon] Search query: ${query}`);

        // Search for sources
        const sources = await aggregator.search(query, type);

        if (sources.length === 0) {
            console.log('[Addon] No sources found');
            return { streams: [] };
        }

        // Filter and rank sources
        const rankedSources = algorithm.filterAndRank(sources);

        if (rankedSources.length === 0) {
            console.log('[Addon] No valid sources after filtering');
            return { streams: [] };
        }

        // Get top results based on config
        const topSources = rankedSources.slice(0, config.display.maxResults);

        // Format for Stremio
        const streams = topSources.map(source => algorithm.formatForStremio(source));

        // Cache results
        if (config.cache.enabled) {
            cache.set(cacheKey, streams);
        }

        console.log(`[Addon] Returning ${streams.length} stream(s)`);
        return { streams };

    } catch (error) {
        console.error('[Addon] Error in stream handler:', error);
        return { streams: [] };
    }
});

/**
 * Build search query from IMDB ID
 * This is a simplified version - in production, you'd want to use OMDB API or similar
 * to get the actual title from IMDB ID
 */
async function buildSearchQuery(imdbId, type, season, episode) {
    // For now, we'll use a simple mapping or return the IMDB ID
    // In a real implementation, you would:
    // 1. Query OMDB API or similar with the IMDB ID
    // 2. Get the movie/series title
    // 3. For series, append season and episode info
    
    // Placeholder: return IMDB ID as query
    // This will work for some torrent sites that support IMDB IDs
    let query = imdbId;
    
    if (type === 'series' && season && episode) {
        query += ` S${season.padStart(2, '0')}E${episode.padStart(2, '0')}`;
    }
    
    return query;
}

// Export the addon interface
module.exports = builder.getInterface();

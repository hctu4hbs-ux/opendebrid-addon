#!/usr/bin/env node

const { serveHTTP } = require('stremio-addon-sdk');
const addonInterface = require('./addon');

const PORT = process.env.PORT || 7000;

// Start the server
serveHTTP(addonInterface, { port: PORT });

console.log('\n===========================================');
console.log('🚀 OpenDebrid Addon Server Started!');
console.log('===========================================');
console.log(`📡 Listening on: http://127.0.0.1:${PORT}`);
console.log(`📦 Manifest URL: http://127.0.0.1:${PORT}/manifest.json`);
console.log('===========================================\n');

// Handle launch flag (for development)
if (process.argv.includes('--launch')) {
    const manifestUrl = `http://127.0.0.1:${PORT}/manifest.json`;
    const stremioUrl = `stremio://${manifestUrl}`;
    
    console.log('🔗 Opening Stremio with addon...');
    console.log(`   URL: ${stremioUrl}\n`);
    
    // Try to open Stremio (works on desktop)
    const open = require('child_process').exec;
    open(`xdg-open "${stremioUrl}"`, (error) => {
        if (error) {
            console.log('⚠️  Could not auto-launch Stremio.');
            console.log(`   Please manually open: ${stremioUrl}\n`);
        }
    });
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n👋 Shutting down OpenDebrid Addon...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n👋 Shutting down OpenDebrid Addon...');
    process.exit(0);
});

# OpenDebrid - إضافة Stremio المجانية الذكية

<div dir="rtl">

## نظرة عامة

**OpenDebrid** هي إضافة مجانية تمامًا لـ Stremio تهدف إلى تقديم تجربة قريبة جدًا من Real Debrid ولكن بدون أي اشتراك أو دفع. الإضافة تعتمد على **خوارزمية ذكية** لاختيار أفضل مصادر التورنت المفتوحة والمجانية، مع التركيز على:

- ✅ **السرعة والاستقرار**: اختيار المصادر ذات السيدرز العالية
- ✅ **الجودة**: تفضيل الجودات العالية (1080p, 4K)
- ✅ **البساطة**: عرض مصدر واحد فقط (الأفضل) بشكل افتراضي
- ✅ **الذكاء**: فلترة تلقائية للمصادر الضعيفة والميتة

</div>

---

## Features

- 🎯 **Smart Source Selection**: Automatically picks the best torrent source based on seeders, quality, and ratio
- 🚀 **Fast & Lightweight**: Minimal overhead with intelligent caching
- 🎬 **Multi-Source Support**: Searches across YTS, 1337x, EZTV, TorrentGalaxy
- 🔍 **Quality Filtering**: Prioritizes high-quality sources (1080p, 4K, BluRay)
- 💾 **Caching**: Reduces search time for popular content
- 🆓 **100% Free**: No subscriptions, no payments, no accounts

---

## Installation

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Stremio installed on your device

### Quick Start

1. **Clone or download this repository**

```bash
git clone https://github.com/yourusername/opendebrid-addon.git
cd opendebrid-addon
```

2. **Install dependencies**

```bash
npm install
```

3. **Start the addon**

```bash
npm start
```

The addon will start on `http://localhost:7000`

4. **Install in Stremio**

Open Stremio and add the addon using this URL:
```
http://localhost:7000/manifest.json
```

Or use the Stremio protocol link:
```
stremio://http://localhost:7000/manifest.json
```

---

## Configuration

You can customize the addon behavior by editing `config.js`:

### Algorithm Weights

```javascript
algorithm: {
    weights: {
        seeders: 0.5,  // How much seeders count matters
        ratio: 0.3,    // How much seeder/leecher ratio matters
        quality: 0.2,  // How much video quality matters
    },
    minSeeders: 5,     // Minimum seeders to consider a source
}
```

### Display Settings

```javascript
display: {
    maxResults: 1,      // Number of sources to show (1 = best only)
    showSeeders: true,  // Show seeder count
    showSize: true,     // Show file size
    showQuality: true,  // Show quality (1080p, etc.)
}
```

### Cache Settings

```javascript
cache: {
    enabled: true,
    ttl: 3600,         // Cache lifetime in seconds (1 hour)
    checkperiod: 600,  // Check for expired cache every 10 minutes
}
```

---

## How It Works

### Architecture

```
Stremio Request → HTTP Server → Addon SDK
                                    ↓
                            Source Aggregator
                                    ↓
                    [YTS, 1337x, EZTV, TorrentGalaxy]
                                    ↓
                            Smart Algorithm
                                    ↓
                    [Filter → Score → Rank]
                                    ↓
                            Best Source(s)
                                    ↓
                            Stremio Client
```

### Smart Algorithm

The addon uses a three-step process:

1. **Aggregation**: Search across multiple torrent sources simultaneously
2. **Filtering**: Remove dead, fake, or low-quality sources based on:
   - Minimum seeders (default: 5)
   - File size sanity checks
   - Quality indicators in title
3. **Ranking**: Score each source using:
   - Seeders count (50% weight)
   - Seeder/leecher ratio (30% weight)
   - Video quality (20% weight)

The highest-scored source is returned to Stremio.

---

## Deployment

### Deploy to Heroku

1. Create a new Heroku app
2. Connect your GitHub repository
3. Deploy the `main` branch
4. Use the Heroku app URL in Stremio: `https://your-app.herokuapp.com/manifest.json`

### Deploy to Railway

1. Create a new Railway project
2. Connect your GitHub repository
3. Railway will auto-detect Node.js and deploy
4. Use the Railway URL in Stremio

### Deploy to Vercel

Note: Vercel has limitations for long-running processes. Consider using Heroku or Railway instead.

---

## Development

### Run in development mode

```bash
npm run dev
```

This will start the server and attempt to open Stremio automatically.

### Project Structure

```
opendebrid-addon/
├── addon.js              # Main addon logic
├── server.js             # HTTP server
├── config.js             # Configuration
├── sourceAggregator.js   # Torrent source aggregation
├── smartAlgorithm.js     # Filtering and ranking logic
├── package.json          # Dependencies
└── README.md             # Documentation
```

---

## Limitations

- **No Caching Server**: Unlike Real Debrid, this addon doesn't cache torrents on a server. It relies on public torrent swarms.
- **Depends on Seeders**: Quality depends on the number of active seeders for each torrent.
- **No VPN Included**: Users should use a VPN if required by their jurisdiction.
- **IMDB ID Limitation**: Currently uses IMDB IDs directly as search queries. For better results, integrate with OMDB API or similar to get actual titles.

---

## Future Improvements

- [ ] Integrate OMDB API for better title resolution
- [ ] Add support for more torrent sources
- [ ] Implement WebTorrent health checks
- [ ] Add user configuration via web interface
- [ ] Support for multiple quality options
- [ ] Anime-specific optimizations (Nyaa.si)

---

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

## License

MIT License - feel free to use and modify as needed.

---

## Disclaimer

This addon is for educational purposes only. Users are responsible for ensuring they comply with their local laws regarding torrenting and streaming. The developers do not condone piracy.

---

<div dir="rtl">

## الدعم والمساعدة

إذا واجهت أي مشاكل أو لديك اقتراحات، يرجى فتح issue على GitHub.

**ملاحظة مهمة**: هذه الإضافة لا تخزن أي محتوى على خوادم خاصة. جميع المصادر من مواقع التورنت العامة والمفتوحة.

</div>

---

**Made with ❤️ by Manus AI**

const TorrentSearchApi = require('torrent-search-api');
const config = require('./config');

class SourceAggregator {
    constructor() {
        this.api = TorrentSearchApi;
        this.initProviders();
    }

    initProviders() {
        // Enable configured providers
        config.sources.enabled.forEach(provider => {
            try {
                this.api.enableProvider(provider);
                console.log(`[SourceAggregator] Enabled provider: ${provider}`);
            } catch (error) {
                console.error(`[SourceAggregator] Failed to enable provider ${provider}:`, error.message);
            }
        });
    }

    /**
     * Search for torrents across all enabled sources
     * @param {string} query - Search query (movie/series title)
     * @param {string} type - Content type (movie/series)
     * @param {number} limit - Maximum results per provider
     * @returns {Promise<Array>} Array of torrent results
     */
    async search(query, type = 'movie', limit = 20) {
        try {
            console.log(`[SourceAggregator] Searching for: ${query} (${type})`);
            
            // Search across all providers
            const results = await this.api.search(query, 'All', limit);
            
            console.log(`[SourceAggregator] Found ${results.length} results`);
            
            // Normalize results to a consistent format
            return results.map(result => this.normalizeResult(result));
        } catch (error) {
            console.error('[SourceAggregator] Search error:', error.message);
            return [];
        }
    }

    /**
     * Normalize torrent result to consistent format
     * @param {Object} result - Raw result from torrent-search-api
     * @returns {Object} Normalized result
     */
    normalizeResult(result) {
        return {
            title: result.title || 'Unknown',
            size: result.size || 'Unknown',
            seeders: parseInt(result.seeds) || 0,
            leechers: parseInt(result.peers) || 0,
            magnet: result.magnet || '',
            provider: result.provider || 'Unknown',
            time: result.time || 'Unknown',
            desc: result.desc || '',
        };
    }

    /**
     * Get magnet link for a specific torrent
     * @param {Object} torrent - Torrent object
     * @returns {Promise<string>} Magnet link
     */
    async getMagnetLink(torrent) {
        try {
            if (torrent.magnet) {
                return torrent.magnet;
            }
            
            // If magnet is not available, try to get it from the provider
            const magnetLink = await this.api.getMagnet(torrent);
            return magnetLink;
        } catch (error) {
            console.error('[SourceAggregator] Failed to get magnet link:', error.message);
            return null;
        }
    }
}

module.exports = SourceAggregator;

// Simple test script for OpenDebrid Addon

const SourceAggregator = require('./sourceAggregator');
const SmartAlgorithm = require('./smartAlgorithm');

async function test() {
    console.log('=== Testing OpenDebrid Components ===\n');

    // Test 1: Source Aggregator
    console.log('Test 1: Source Aggregator');
    const aggregator = new SourceAggregator();
    
    console.log('Searching for "Inception 2010"...');
    const sources = await aggregator.search('Inception 2010', 'movie', 10);
    console.log(`Found ${sources.length} sources\n`);

    if (sources.length > 0) {
        console.log('Sample source:');
        console.log(JSON.stringify(sources[0], null, 2));
        console.log();
    }

    // Test 2: Smart Algorithm
    console.log('\nTest 2: Smart Algorithm');
    const algorithm = new SmartAlgorithm();
    
    const ranked = algorithm.filterAndRank(sources);
    console.log(`After filtering: ${ranked.length} sources\n`);

    if (ranked.length > 0) {
        console.log('Top 3 sources:');
        ranked.slice(0, 3).forEach((source, index) => {
            console.log(`${index + 1}. ${source.title}`);
            console.log(`   Score: ${source.score.toFixed(2)}, Seeders: ${source.seeders}, Size: ${source.size}`);
        });
    }

    console.log('\n=== Test Complete ===');
    process.exit(0);
}

test().catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
});
